import streamlit as st
import os

st.title("Eco360 Furniture Selector")

furniture_items = {
    "Chair": "images/chair.jpg",
    "Table": "images/table.jpg",
    "Sofa": "images/sofa.jpg"
}

furniture_choice = st.selectbox("Choose furniture", list(furniture_items.keys()))

image_path = furniture_items[furniture_choice]
exists = os.path.exists(image_path)
st.write(f"Image file exists? {exists}")

if exists:
    st.image(image_path, caption=f"Selected: {furniture_choice}", width=300)
else:
    st.error(f"Error: Image file not found at '{image_path}'. Please check your folder structure.")